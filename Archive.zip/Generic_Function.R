#' @name %%
#' @title Extract NIfTI 3D Image %% attribute
#' @docType methods 
#' @param object is an object of class \code{nifti}
#' @param value Value to assign to %% 
#' @description Methods that act on the ``%%'' in the NIfTI header.
#' @rdname %%-methods
#' @aliases %%-methods 
#' @aliases %%
#' @export
setGeneric("%%", function(object) standardGeneric("%%"))

#' @name %%
#' @rdname %%-methods
#' @aliases %%,nifti-method
setMethod("%%", "nifti", function(object) { object@"%%" })

#' @name %%
#' @rdname %%-methods
#' @aliases %%,character-method   
setMethod("%%", "character", function(object){
  object = path.expand(object)
  stopifnot(file.exists(object))
  res = fslval(object, keyword = "%%", verbose = FALSE)
  res = as.%type(res)
})

#' @name %%
#' @rdname %%-methods
#' @aliases %%<- 
setGeneric("%%<-", function(object, value) { standardGeneric("%%<-") })

#' @name %%
#' @rdname %%-methods
#' @aliases %%<-,nifti-method
setMethod("%%<-", 
          signature(object="nifti"), 
          function(object, value) { 
            object@"%%" <- value 
            return(object)
          })

